<?php

declare(strict_types=1);

namespace HmApi\Domain;

use DateTimeImmutable;

/** Validated input to create or update an event. */
final class EventData
{
    public function __construct(
        public readonly string $title,
        public readonly string $description,
        public readonly DateTimeImmutable $date,
        public readonly ?string $link,
        public readonly ?string $price,
        public readonly string $currency,
        public readonly bool $published,
    ) {
    }
}
