-- Hockey Management back office — MySQL 8 / MariaDB 10.6+
-- Run once in hPanel → Databases → phpMyAdmin → (your database) → SQL

CREATE TABLE IF NOT EXISTS admin_user (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS events (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title        VARCHAR(150)  NOT NULL,
  subtitle     VARCHAR(200)  NULL,
  venue        VARCHAR(150)  NULL,
  description  TEXT          NOT NULL,
  event_date   DATETIME      NOT NULL,
  link         VARCHAR(500)  NULL,
  price        DECIMAL(10,2) NULL,
  currency     CHAR(3)       NOT NULL DEFAULT 'ARS',
  image_path   VARCHAR(255)  NULL,
  is_published TINYINT(1)    NOT NULL DEFAULT 1,
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_events_upcoming (is_published, event_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_attempts (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ip           VARCHAR(45) NOT NULL,
  attempted_at DATETIME    NOT NULL,
  INDEX idx_login_attempts_ip (ip, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
